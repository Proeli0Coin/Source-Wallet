Sample configuration files for:

SystemD: proeliod.service
Upstart: proeliod.conf
OpenRC:  proeliod.openrc
         proeliod.openrcconf
CentOS:  proeliod.init

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
