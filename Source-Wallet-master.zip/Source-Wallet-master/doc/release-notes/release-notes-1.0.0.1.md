v1.0.0.1

1. Introduction of control of issued masternodes
2. Improve the design of the application interface
